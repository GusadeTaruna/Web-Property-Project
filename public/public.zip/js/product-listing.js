$(document).ready(function() {
    $('#location-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Location',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});


$(document).ready(function() {
    $('#type-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Type',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});


$(document).ready(function() {
    $('#bed-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Bedrooms',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});

$(document).ready(function() {
    $('#title-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Title',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});

$(document).ready(function() {
    $('#minimum-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Price',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});

$(document).ready(function() {
    $('#maximum-select').multiselect({
    	includeSelectAllOption: true,
    	nonSelectedText: 'Any Price',
    	enableFiltering: true,
    	enableCaseInsensitiveFiltering: true,
     	maxHeight: 450,     
        buttonWidth: '100%'
    });
});