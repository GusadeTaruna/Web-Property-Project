<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact Form</title>
</head>
<body>
    <h2>New Email arrived!</h2>
    <div>
        <h3>Email from : <?php echo e($details['name']); ?> (<?php echo e($details['email_from']); ?>)</h3>
    </div>
    Message: <br>
    <p><?php echo e($details['msg']); ?></p>
    
</body>
</html><?php /**PATH H:\Gusade\Job\Krisna\Property-project-1-backend\resources\views/emails/contact-mail.blade.php ENDPATH**/ ?>